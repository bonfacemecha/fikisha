@extends('layouts.app')

@section('content')
<fleet-component></fleet-component>

@endsection