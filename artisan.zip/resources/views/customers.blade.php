@extends('layouts.app')

@section('content')

<customers-component></customers-component>

@endsection